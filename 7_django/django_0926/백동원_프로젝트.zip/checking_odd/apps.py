from django.apps import AppConfig


class CheckingOddConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'checking_odd'
